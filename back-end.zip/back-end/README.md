# back-end

## Description

Ici, le back-end de l'application

## Prérequis

Pour exécuter ce projet, vous devez avoir Node.js et Express.js Sequelize installés sur votre système.

## Installation

Pour démarrer le serveur : npm start